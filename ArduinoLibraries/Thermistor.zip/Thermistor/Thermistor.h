#ifndef _THERMISTOR_H
#define _THERMISTOR_H

#include "Timer.h"
#include "Arduino.h"

/// @author Rhalf Wendel D Caacbay <rhalfcaacbay@gmail.com>
//typedef void (* CallBack)();

class Thermistor {

public:

  Thermistor(uint8_t pin);
  Thermistor(uint8_t pin, float resistor);

 
  float getCelcius();
  float getFahrenheit();

  uint8_t getPin(void);

private:
  uint8_t _pin;
  float _r1 = 100000;
  float _logR2, _r2, _t;
  float _c1 = 1.009249522e-03, _c2 = 2.378405444e-04, _c3 = 2.019202697e-07;

};
#endif // _THERMISTOR_H
