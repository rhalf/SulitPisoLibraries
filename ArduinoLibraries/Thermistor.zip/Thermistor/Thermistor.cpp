#include "Thermistor.h"
#include "Arduino.h"
#include "Timer.h"
// typedef void (* CallBack)();
Thermistor::Thermistor(uint8_t pin) {
  _pin = pin;
  pinMode(_pin, INPUT);
}

Thermistor::Thermistor(uint8_t pin, float resistor) {
  _pin = pin;
  _r1 = resistor;
  pinMode(_pin, INPUT);
}


float Thermistor::getCelcius() {
  uint16_t vo = analogRead(_pin);
  // _r2 = _r1 * (1023.0 / (float)vo - 1.0);
  // _logR2 = log(_r2);
  // _t = (1.0 / (_c1 + (_c2*_logR2) + (_c3*_logR2*_logR2*_logR2)));
  //return _t - 273.15;
  return((float) vo);
}

float Thermistor::getFahrenheit() {
  return  (getCelcius() * 9.0)/ 5.0 + 32.0; 
}

uint8_t Thermistor::getPin(void) {
  return  _pin;
}